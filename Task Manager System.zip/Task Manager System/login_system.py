import tkinter as tk
from tkinter import messagebox, ttk
import csv
import os

# Faylasha loo baahan yahay
EMPLOYEE_FILE = "employees.txt"
TASK_FILE = "tasks.csv"

# Haddii faylasha aysan jirin, samee
if not os.path.exists(EMPLOYEE_FILE):
    with open(EMPLOYEE_FILE, "w") as f:
        f.write("admin,admin123,admin\n")

if not os.path.exists(TASK_FILE):
    with open(TASK_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Shaqaalaha", "Magaca Shaqada", "Waqtiga Qabashada", "Nooca Shaqada"])

# Function-ka Login
def login():
    username = username_entry.get()
    password = password_entry.get()
    with open(EMPLOYEE_FILE, "r") as f:
        for line in f:
            user, passw, role = line.strip().split(",")
            if username == user and password == passw:
                if role == "admin":
                    admin_dashboard()
                elif role == "employee":
                    employee_dashboard(username)
                return
    messagebox.showerror("Error", "Username ama Password waa qalad!")

# Admin Dashboard
def admin_dashboard():
    login_window.destroy()
    admin_window = tk.Tk()
    admin_window.title("Admin Dashboard")
    admin_window.geometry("800x500")
    admin_window.configure(bg="#f0f0f0")

    tk.Label(admin_window, text="Admin Dashboard", font=("Arial", 20), bg="#f0f0f0", fg="#333").pack(pady=10)
    
    # Table-ka xogta
    tree = ttk.Treeview(admin_window, columns=("Shaqaalaha", "Magaca Shaqada", "Waqtiga Qabashada", "Nooca Shaqada"), show="headings")
    tree.heading("Shaqaalaha", text="Shaqaalaha")
    tree.heading("Magaca Shaqada", text="Magaca Shaqada")
    tree.heading("Waqtiga Qabashada", text="Waqtiga Qabashada")
    tree.heading("Nooca Shaqada", text="Nooca Shaqada")
    tree.column("Shaqaalaha", width=150)
    tree.column("Magaca Shaqada", width=200)
    tree.column("Waqtiga Qabashada", width=150)
    tree.column("Nooca Shaqada", width=150)
    tree.pack(pady=20, padx=20, fill="both", expand=True)

    def load_tasks():
        for row in tree.get_children():
            tree.delete(row)
        with open(TASK_FILE, "r") as f:
            reader = csv.reader(f)
            next(reader)
            for row in reader:
                tree.insert("", "end", values=row)

    load_tasks()

    # Refresh button
    tk.Button(admin_window, text="Refresh", command=load_tasks, bg="#4caf50", fg="white", font=("Arial", 12)).pack(pady=10)

    admin_window.mainloop()

# Employee Dashboard
def employee_dashboard(username):
    login_window.destroy()
    employee_window = tk.Tk()
    employee_window.title("Employee Dashboard")
    employee_window.geometry("400x400")
    employee_window.configure(bg="#e0f7fa")

    tk.Label(employee_window, text=f"Welcome {username}", font=("Arial", 16), bg="#e0f7fa").pack(pady=10)

    tk.Label(employee_window, text="Magaca Shaqada:", font=("Arial", 12), bg="#e0f7fa").pack(pady=5)
    task_name_entry = tk.Entry(employee_window, font=("Arial", 12))
    task_name_entry.pack(pady=5)

    tk.Label(employee_window, text="Waqtiga Qabashada:", font=("Arial", 12), bg="#e0f7fa").pack(pady=5)
    task_time_entry = tk.Entry(employee_window, font=("Arial", 12))
    task_time_entry.pack(pady=5)

    tk.Label(employee_window, text="Nooca Shaqada:", font=("Arial", 12), bg="#e0f7fa").pack(pady=5)
    task_type_entry = tk.Entry(employee_window, font=("Arial", 12))
    task_type_entry.pack(pady=5)

    def submit_task():
        task_name = task_name_entry.get()
        task_time = task_time_entry.get()
        task_type = task_type_entry.get()
        if task_name and task_time and task_type:
            with open(TASK_FILE, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([username, task_name, task_time, task_type])
            messagebox.showinfo("Success", "Shaqada waa la gudbiyay!")
            task_name_entry.delete(0, "end")
            task_time_entry.delete(0, "end")
            task_type_entry.delete(0, "end")
        else:
            messagebox.showerror("Error", "Fadlan buuxi dhammaan xogta!")

    tk.Button(employee_window, text="Submit", command=submit_task, bg="#00796b", fg="white", font=("Arial", 12)).pack(pady=20)

    employee_window.mainloop()

# Login Window
login_window = tk.Tk()
login_window.title("Login")
login_window.geometry("300x300")

tk.Label(login_window, text="Login", font=("Arial", 18)).pack(pady=20)

tk.Label(login_window, text="Username:", font=("Arial", 12)).pack(pady=5)
username_entry = tk.Entry(login_window, font=("Arial", 12))
username_entry.pack(pady=5)

tk.Label(login_window, text="Password:", font=("Arial", 12)).pack(pady=5)
password_entry = tk.Entry(login_window, font=("Arial", 12), show="*")
password_entry.pack(pady=5)

tk.Button(login_window, text="Login", command=login, bg="#2196f3", fg="white", font=("Arial", 12)).pack(pady=20)

login_window.mainloop()
